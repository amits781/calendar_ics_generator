package com.aidyn.cal;

import java.io.FileOutputStream;
import java.io.IOException;
import java.text.ParseException;
import java.util.HashMap;
import java.util.Map;

import net.fortuna.ical4j.data.CalendarOutputter;
import net.fortuna.ical4j.data.ParserException;
import net.fortuna.ical4j.model.Property;
import net.fortuna.ical4j.model.TimeZone;
import net.fortuna.ical4j.model.TimeZoneRegistry;
import net.fortuna.ical4j.model.TimeZoneRegistryFactory;
import net.fortuna.ical4j.model.component.VEvent;
import net.fortuna.ical4j.model.component.VTimeZone;
import net.fortuna.ical4j.model.parameter.Value;
import net.fortuna.ical4j.model.property.CalScale;
import net.fortuna.ical4j.model.property.Description;
import net.fortuna.ical4j.model.property.ProdId;
import net.fortuna.ical4j.model.property.Version;
import net.fortuna.ical4j.util.RandomUidGenerator;
import net.fortuna.ical4j.util.UidGenerator;
import net.fortuna.ical4j.validate.ValidationException;

public class CalendarMain {

	public static void main(String[] args) throws IOException, ValidationException, ParserException {

		String calFile = "C:/Users/Amit/Downloads/mycalendar.ics";
		TimeZoneRegistry registry = TimeZoneRegistryFactory.getInstance().createRegistry();
		TimeZone timezone = registry.getTimeZone("Asia/Calcutta");
		VTimeZone tz = timezone.getVTimeZone();
		// Creating a new calendar
		net.fortuna.ical4j.model.Calendar calendar = new net.fortuna.ical4j.model.Calendar();
		calendar.getProperties().add(new ProdId("-//Ben Fortuna//iCal4j 1.0//EN"));
		calendar.getProperties().add(Version.VERSION_2_0);
		calendar.getProperties().add(CalScale.GREGORIAN);

		int year = 2021;
		int workingSaturdays[][] = { { 16, 23 }, // January
				{ 6, 27 }, // February
				{}, // March
				{}, // April
				{ 29 }, // May
				{}, // June
				{ 31 }, // July
				{ 14 }, // August
				{}, // September
				{ 9, 30 }, // October
				{ 20 }, // November
				{} // December
		};

		Map<String, String> weekendHolidays = GcalAPIIntegration.processWeekDays(workingSaturdays, year);
		Map<String, String> generalHolidays = new HashMap<String, String>();
		Map<String, String> electiveHolidays = new HashMap<String, String>();
		generalHolidays.put(GcalAPIIntegration.converDate("1-Jan-2021"), "New Year's Day");
		generalHolidays.put(GcalAPIIntegration.converDate("14-Jan-2021"), "Makar Sankranti");
		generalHolidays.put(GcalAPIIntegration.converDate("26-Jan-2021"), "Republic Day");
		generalHolidays.put(GcalAPIIntegration.converDate("29-Mar-2021"), "Holi");
		generalHolidays.put(GcalAPIIntegration.converDate("5-Jul-2021"), "Metacube Long Weekend");
		generalHolidays.put(GcalAPIIntegration.converDate("30-Aug-2021"), "Janmashtmi");
		generalHolidays.put(GcalAPIIntegration.converDate("15-Oct-2021"), "Dussehra");
		generalHolidays.put(GcalAPIIntegration.converDate("4-Nov-2021"), "Diwali");
		generalHolidays.put(GcalAPIIntegration.converDate("5-Nov-2021"), "Govardhan Puja");
		generalHolidays.put(GcalAPIIntegration.converDate("24-Dec-2021"), "Christmas Eve");
		electiveHolidays.put(GcalAPIIntegration.converDate("14-May-2021"), "EL-1 Id-ul-Fitr");
		electiveHolidays.put(GcalAPIIntegration.converDate("21-Jul-2021"), "EL-1 Id-ul-Zuha (Bakrid)");
		electiveHolidays.put(GcalAPIIntegration.converDate("10-Sep-2021"), "EL-1 Ganesh Chaturthi");

		int counter = 0;
		System.out.println("Step 1/3 ------- Weekend Holidays -------");
		for (Map.Entry<String, String> entry : weekendHolidays.entrySet()) {
			System.out.println("Sl No. " + ++counter + "/" + weekendHolidays.size());
			try {
				calendar.getComponents()
						.add(createCalendarEvent(entry.getKey(), "Metacube Weekend Holiday", entry.getValue(), tz));
			} catch (ParseException e) {
				System.out.println("Error in Weekends");
				e.printStackTrace();
			}
		}
		counter = 0;
		System.out.println("Step 2/3 ------- Holidays -------");
		for (Map.Entry<String, String> entry : generalHolidays.entrySet()) {
			System.out.println("Sl No. " + ++counter + "/" + generalHolidays.size());
			try {
				calendar.getComponents()
						.add(createCalendarEvent(entry.getKey(), "Metacube Holiday", entry.getValue(), tz));
			} catch (ParseException e) {
				System.out.println("Error in Holiday");
				e.printStackTrace();
			}
		}
		counter = 0;
		System.out.println("Step 3/3 ------- Elective Holidays -------");
		for (Map.Entry<String, String> entry : electiveHolidays.entrySet()) {
			System.out.println("Sl No. " + ++counter + "/" + electiveHolidays.size());
			try {
				calendar.getComponents()
						.add(createCalendarEvent(entry.getKey(), "Metacube Elective Holiday", entry.getValue(), tz));
			} catch (ParseException e) {
				System.out.println("Error in Elective");
				e.printStackTrace();
			}
		}

		// Saving an iCalendar file
		FileOutputStream fout = new FileOutputStream(calFile);

		CalendarOutputter outputter = new CalendarOutputter();
		outputter.setValidating(false);
		outputter.output(calendar, fout);
	}

	public static VEvent createCalendarEvent(String date, String title, String description, VTimeZone tz)
			throws ParseException {
		VEvent event = new VEvent(new net.fortuna.ical4j.model.Date(date, "yyyy-MM-dd"), title);
		event.getProperties().add(new Description(description));

		// initialise as an all-day event..
		((Property) event.getProperties().getProperty(Property.DTSTART)).getParameters().add(Value.DATE);

		event.getProperties().add(tz.getTimeZoneId());

		UidGenerator uidGenerator = new RandomUidGenerator();
		event.getProperties().add(uidGenerator.generateUid());
		System.out.printf("Event created:\n\tTitle: %s\n\tDescription: %s\n\tDate: %s\n", title, description, date);
		return event;

	}
}
