package com.aidyn.cal;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.security.GeneralSecurityException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.Month;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import com.google.api.client.auth.oauth2.Credential;
import com.google.api.client.extensions.java6.auth.oauth2.AuthorizationCodeInstalledApp;
import com.google.api.client.extensions.jetty.auth.oauth2.LocalServerReceiver;
import com.google.api.client.googleapis.auth.oauth2.GoogleAuthorizationCodeFlow;
import com.google.api.client.googleapis.auth.oauth2.GoogleClientSecrets;
import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.client.util.DateTime;
import com.google.api.client.util.store.FileDataStoreFactory;
import com.google.api.services.calendar.Calendar;
import com.google.api.services.calendar.CalendarScopes;
import com.google.api.services.calendar.model.CalendarList;
import com.google.api.services.calendar.model.CalendarListEntry;
import com.google.api.services.calendar.model.Event;
import com.google.api.services.calendar.model.Event.Reminders;
import com.google.api.services.calendar.model.EventDateTime;
import com.google.api.services.calendar.model.Events;

public class GcalAPIIntegration {
	private static final String APPLICATION_NAME = "Google Calendar API Java";
	private static final JsonFactory JSON_FACTORY = JacksonFactory.getDefaultInstance();
	private static final String TOKENS_DIRECTORY_PATH = "tokens";

	/**
	 * Global instance of the scopes required by this quickstart. If modifying these
	 * scopes, delete your previously saved tokens/ folder.
	 */
	private static final List<String> SCOPES = Collections.singletonList(CalendarScopes.CALENDAR);
	private static final String CREDENTIALS_FILE_PATH = "./credentials.json";

	/**
	 * Creates an authorized Credential object.
	 * 
	 * @param HTTP_TRANSPORT The network HTTP Transport.
	 * @return An authorized Credential object.
	 * @throws IOException If the credentials.json file cannot be found.
	 */
	private static Credential getCredentials(final NetHttpTransport HTTP_TRANSPORT) throws IOException {
		// Load client secrets.
		InputStream in = CalendarMain.class.getResourceAsStream(CREDENTIALS_FILE_PATH);
		if (in == null) {
			throw new FileNotFoundException("Resource not found: " + CREDENTIALS_FILE_PATH);
		}
		GoogleClientSecrets clientSecrets = GoogleClientSecrets.load(JSON_FACTORY, new InputStreamReader(in));

		// Build flow and trigger user authorization request.
		GoogleAuthorizationCodeFlow flow = new GoogleAuthorizationCodeFlow.Builder(HTTP_TRANSPORT, JSON_FACTORY,
				clientSecrets, SCOPES)
						.setDataStoreFactory(new FileDataStoreFactory(new java.io.File(TOKENS_DIRECTORY_PATH)))
						.setAccessType("offline").build();
		LocalServerReceiver receiver = new LocalServerReceiver.Builder().setPort(8888).build();
		return new AuthorizationCodeInstalledApp(flow, receiver).authorize("user");
	}

	public static void main(String... args) throws IOException, GeneralSecurityException {
		// Build a new authorized API client service.
		final NetHttpTransport HTTP_TRANSPORT = GoogleNetHttpTransport.newTrustedTransport();
		Calendar service = new Calendar.Builder(HTTP_TRANSPORT, JSON_FACTORY, getCredentials(HTTP_TRANSPORT))
				.setApplicationName(APPLICATION_NAME).build();
		int year = 2021;
		int workingSaturdays[][] = { { 16, 23 }, // January
				{ 6, 27 }, // February
				{}, // March
				{}, // April
				{ 29 }, // May
				{}, // June
				{ 31 }, // July
				{ 14 }, // August
				{}, // September
				{ 9, 30 }, // October
				{ 20 }, // November
				{} // December
		};

		Map<String, String> weekendHolidays = processWeekDays(workingSaturdays, year);
		Map<String, String> generalHolidays = new HashMap<String, String>();
		Map<String, String> electiveHolidays = new HashMap<String, String>();
		generalHolidays.put(converDate("1-Jan-2021"), "New Year's Day");
		generalHolidays.put(converDate("14-Jan-2021"), "Makar Sankranti");
		generalHolidays.put(converDate("26-Jan-2021"), "Republic Day");
		generalHolidays.put(converDate("29-Mar-2021"), "Holi");
		generalHolidays.put(converDate("5-Jul-2021"), "Metacube Long Weekend");
		generalHolidays.put(converDate("30-Aug-2021"), "Janmashtmi");
		generalHolidays.put(converDate("15-Oct-2021"), "Dussehra");
		generalHolidays.put(converDate("4-Nov-2021"), "Diwali");
		generalHolidays.put(converDate("5-Nov-2021"), "Govardhan Puja");
		generalHolidays.put(converDate("24-Dec-2021"), "Christmas Eve");
		electiveHolidays.put(converDate("14-May-2021"), "EL-1 Id-ul-Fitr");
		electiveHolidays.put(converDate("21-Jul-2021"), "EL-1 Id-ul-Zuha (Bakrid)");
		electiveHolidays.put(converDate("10-Sep-2021"), "EL-1 Ganesh Chaturthi");
		String calName = "amit.sharma2@metacube.com";
		int counter = 0;
//		for (Map.Entry<String, String> entry : weekendHolidays.entrySet()) {
//			createCalendarEvent(service, entry.getKey(), "Metacube Weekend Holiday", entry.getValue());
//		}
		counter = 0;
//		for (Map.Entry<String, String> entry : generalHolidays.entrySet()) {
//			createCalendarEvent(service, entry.getKey(), "Metacube Holiday", entry.getValue());
//		}
//		counter = 0;
//		System.out.println("Step 3/3 ------- Elective Holidays -------");
//		for (Map.Entry<String, String> entry : electiveHolidays.entrySet()) {
//			System.out.println("Sl No. " + ++counter + "/" + electiveHolidays.size());
//			createCalendarEvent(service, entry.getKey(), "Metacube Elective Holiday", entry.getValue(), calName);
//		}

		listAndDeleteAllUpcommingEvents(service, calName);
//		listAllCalendars(service);
//		createNewCalendar(service);
	}

	public static String converDate(String date) {
		SimpleDateFormat userFormat = new SimpleDateFormat("dd-MMM-yyyy");
		SimpleDateFormat finalFormatForGCal = new SimpleDateFormat("yyyy-MM-dd");
		Date dateTmp;
		try {
			dateTmp = userFormat.parse(date);
			return finalFormatForGCal.format(dateTmp);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	public static Map<String, String> processWeekDays(int workingSaturdays[][], int year) {
		Map<String, String> weekendEvents = new HashMap<>();
		for (int i = 0; i < workingSaturdays.length; i++) {
			Month month = Month.of(i + 1);
			List<Integer> daysExcludedList = IntStream.of(workingSaturdays[i]).boxed().collect(Collectors.toList());
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
			IntStream.rangeClosed(1, YearMonth.of(year, month).lengthOfMonth())
					.mapToObj(day -> LocalDate.of(year, month, day))
					.filter(date -> date.getDayOfWeek() == DayOfWeek.SATURDAY).forEach(date -> {
						if (!daysExcludedList.contains(date.getDayOfMonth())) {
							weekendEvents.put(date.format(formatter), "Weekend Saturday");
						}
					});
			IntStream.rangeClosed(1, YearMonth.of(year, month).lengthOfMonth())
					.mapToObj(day -> LocalDate.of(year, month, day))
					.filter(date -> date.getDayOfWeek() == DayOfWeek.SUNDAY).forEach(date -> {
						weekendEvents.put(date.format(formatter), "Weekend Sunday");
					});
		}

		return weekendEvents;

	}

	public static void createCalendarEvent(Calendar service, String date, String title, String description,
			String calName) {
		try {
			Reminders reminders = new Reminders();
			reminders.setUseDefault(false);
			Event event = new Event().setReminders(reminders).setSummary(title).setDescription(description);

			DateTime startDateTime = new DateTime(date);
			EventDateTime start = new EventDateTime().setDate(startDateTime).setTimeZone("IST");
			event.setStart(start);

			DateTime endDateTime = new DateTime(date);
			EventDateTime end = new EventDateTime().setDate(endDateTime).setTimeZone("IST");
			event.setEnd(end);

			event = service.events().insert(calName, event).execute();
			System.out.printf("Event created:\n\tTitle: %s\n\tDescription: %s\n\tDate: %s\n\tLink %s\n", title,
					description, date, event.getHtmlLink());
		} catch (Exception e) {
			System.out.println("Error creating event:" + title + " for date:" + date);
			System.out.println("Exception is :" + e.getMessage());
		}

	}

	public static void listAndDeleteAllUpcommingEvents(Calendar service, String calName) throws IOException {
		DateTime now = new DateTime(System.currentTimeMillis());
		Events events = service.events().list(calName).setMaxResults(370).setTimeMin(now).setOrderBy("startTime")
				.setSingleEvents(true).execute();
		List<Event> items = events.getItems();
		if (items.isEmpty()) {
			System.out.println("No upcoming events found.");
		} else {
			System.out.println("Upcoming events");
			for (Event event : items) {
				DateTime start = event.getStart().getDateTime();
				if (start == null) {
					start = event.getStart().getDate();
				}
				String eventId = event.getId();
				System.out.printf("%s %s (%s)\n", eventId, event.getSummary(), start);
				service.events().delete("primary", eventId).execute();
				System.out.printf("Event with ID %s deleted\n", eventId);
			}
		}
	}

	public static void listAllCalendars(Calendar service) throws IOException {

		// Iterate through entries in calendar list
		String pageToken = null;
		do {
			CalendarList calendarList = service.calendarList().list().setPageToken(pageToken).execute();
			List<CalendarListEntry> items = calendarList.getItems();

			for (CalendarListEntry calendarListEntry : items) {
				System.out.println(calendarListEntry.getSummary() + "||" + calendarListEntry.getId());
			}
			pageToken = calendarList.getNextPageToken();
		} while (pageToken != null);
	}

	public static void createNewCalendar(Calendar service) throws IOException {

		com.google.api.services.calendar.model.Calendar calendar = new com.google.api.services.calendar.model.Calendar();
		calendar.setSummary("Holidays from Metacube");
		calendar.setTimeZone("Asia/Calcutta");

		// Insert the new calendar
		com.google.api.services.calendar.model.Calendar createdCalendar = service.calendars().insert(calendar)
				.execute();

		System.out.println(createdCalendar.getId());
	}
}
